package eord.dao;

import java.util.List;
import java.util.Map;

import kr.fujitsu.ffw.control.ActionForm;
import kr.fujitsu.ffw.control.cfg.svc.Service;
import kr.fujitsu.ffw.model.AbstractDAO2;
import kr.fujitsu.ffw.model.SqlWrapper;
import kr.fujitsu.ffw.util.String2;
import ecom.util.Util;

public class EOrd101DAO_back extends AbstractDAO2{
	public StringBuffer getList(ActionForm form) throws Exception {
		
		SqlWrapper sql = null;
		Service svc = null;
		StringBuffer sb = null;
		int i = 0;
		String query = "";
		
		try{
			
			sql = new SqlWrapper();
			svc = (Service)form.getService();
			sb = new StringBuffer();

			String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
			String vencd = String2.nvl(form.getParam("vencd"));	    //���»��ڵ�
			String pumbuncd = String2.nvl(form.getParam("pubumCd"));   //ǰ���ڵ�
			String slip_proc_falg = String2.nvl(form.getParam("slip_proc_falg"));	//��ǥ����
			String gjDate = String2.nvl(form.getParam("gjDate"));			//������
			String sDate = String2.nvl(form.getParam("sDate")).replaceAll("/", "");				//������
			String eDate = String2.nvl(form.getParam("eDate")).replaceAll("/", "");				//������
			String slip_falg = String2.nvl(form.getParam("slip_falg"));			//��ǥ����
			
			
			connect("pot");
			
			sql.put(svc.getQuery("SEL_LIST"));
			sql.setString(++i, slip_proc_falg);
			sql.setString(++i, pumbuncd);
			sql.setString(++i, vencd);
			sql.setString(++i, slip_falg);
			sql.setString(++i, strcd);
			
			if("0".equals(gjDate)){					// ������
				sql.put(svc.getQuery("SEL_ORD_DT"));
				sql.setString(++i, sDate);
				sql.setString(++i, eDate);
			} else if("1".equals(gjDate)){			// ����Ȯ����
				sql.put(svc.getQuery("SEL_ORD_CONF"));    
				sql.setString(++i, sDate);
				sql.setString(++i, eDate);	             
			} else if("2".equals(gjDate)){			// ��ǰ������
				sql.put(svc.getQuery("SEL_DELI_DT"));
				sql.setString(++i, sDate);
				sql.setString(++i, eDate);		
			} else if("3".equals(gjDate)){			// ��ǰȮ����
				sql.put(svc.getQuery("SEL_CHK_DT"));
				sql.setString(++i, sDate);
				sql.setString(++i, eDate);	
			}
			
			
			sql.put(svc.getQuery("SEL_ORDERBY"));
			
			sb = executeQueryByAjax(sql);
			
			
			
		}catch(Exception e){
			throw e;
		}
		
		return sb;
	}
	
	public StringBuffer getMaster(ActionForm form) throws Exception {
		
		StringBuffer sb = null;
		SqlWrapper sql = null;
		Service svc = null;
		int i = 0;		
		
		try{
			sql = new SqlWrapper();
			svc = (Service) form.getService();
			sb = new StringBuffer();
			
			String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
			String slip_no = String2.nvl(form.getParam("slip_no"));	//��ǥ��ȣ
			
			connect("pot");
			
			sql.put(svc.getQuery("SEL_MASTER"));
			sql.setString(++i, strcd);
			sql.setString(++i, slip_no);
			
			sb = executeQueryByAjax(sql);
			
		}catch(Exception e){
			throw e;
		}
		return sb;
	}
	
public StringBuffer getDetail(ActionForm form) throws Exception {
		
		StringBuffer sb = null;
		SqlWrapper sql = null;
		Service svc = null;
		int i = 0;		
		
		try{
			sql = new SqlWrapper();
			svc = (Service) form.getService();
			sb = new StringBuffer();
			
			String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
			String slip_no = String2.nvl(form.getParam("slip_no"));	//��ǥ��ȣ
			
			connect("pot");
			
			sql.put(svc.getQuery("SEL_DETAIL"));
			sql.setString(++i, strcd);
			sql.setString(++i, slip_no);
			
			sb = executeQueryByAjax(sql);
			
		}catch(Exception e){
			throw e;
		}
		return sb;
}
	
public StringBuffer getpumbunGbBun(ActionForm form) throws Exception {
		
		StringBuffer sb = null;
		SqlWrapper sql = null;
		Service svc = null;
		int i = 0;		
		
		try{
			sql = new SqlWrapper();
			svc = (Service) form.getService();
			sb = new StringBuffer();
			
			String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
			String ven_cd = String2.nvl(form.getParam("vencd"));	//���»��ڵ�
			String pumbuncd = String2.nvl(form.getParam("pumbuncd"));	//ǰ���ڵ�
			
			connect("pot");
			
			sql.put(svc.getQuery("SEL_PUMBUNGB"));
			sql.setString(++i, strcd);
			sql.setString(++i, pumbuncd);
			
			sb = executeQueryByAjax(sql);
			
		}catch(Exception e){
			throw e;
		}
		return sb;
}

public StringBuffer getMarginFlag(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;		
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
		String pumbuncd = String2.nvl(form.getParam("pumbuncd"));	//���»��ڵ�
		String marginAppdt = String2.nvl(form.getParam("marginAppdt")).trim().replaceAll("/", "");	//ǰ���ڵ�
		
		connect("pot");
		
		sql.put(svc.getQuery("SEL_MARGIN_FLAG"));
		sql.setString(++i, strcd);
		sql.setString(++i, pumbuncd);
		sql.setString(++i, marginAppdt);
		
		sb = executeQueryByAjax(sql);
		
	}catch(Exception e){
		throw e;
	}
	return sb;
}

public StringBuffer getMarginRate(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;		
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String strcd = String2.nvl(form.getParam("strcd"));											//���ڵ�
		String pumbuncd = String2.nvl(form.getParam("pumbuncd"));									//���»��ڵ�
		String marginAppdt = String2.nvl(form.getParam("marginAppdt")).trim().replaceAll("/", "");	//����������
		String marginGbn = String2.nvl(form.getParam("marginGbn"));									//��籸��
		
		connect("pot");
		
		sql.put(svc.getQuery("SEL_MARGIN_RATE"));
		sql.setString(++i, strcd);
		sql.setString(++i, pumbuncd);
		sql.setString(++i, marginAppdt);
		sql.setString(++i, marginGbn);
		
		sb = executeQueryByAjax(sql);
		
		
		
	}catch(Exception e){
		throw e;
	}
	return sb;
}

public StringBuffer slip_flag(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;		
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String strcd = String2.nvl(form.getParam("strcd"));		//���ڵ�
		String slip_no = String2.nvl(form.getParam("slip_no"));	//��ǥ��ȣ
		
		connect("pot");
		
		sql.put(svc.getQuery("MASTER_SLIP"));
		sql.setString(++i, strcd);
		sql.setString(++i, slip_no);
		
		sb = executeQueryByAjax(sql);
		
	}catch(Exception e){
		throw e;
	}
	return sb;
}

public StringBuffer detailDel(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int ret = 0;
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String del_status [] = String2.nvl(form.getParam("de_rowStatus")).split("/");										//����
		String del_strcd [] = String2.nvl(form.getParam("de_strcd")).split("/");											//���ڵ�
		String de_slip_no [] = String2.nvl(form.getParam("de_slip_no")).split("/");											//��ǥ��ȣ
		String de_ord_seqno [] = String2.nvl(form.getParam("de_ord_seqno")).split("/");									    //��ǥ����
		
		connect("pot");
		begin();
		
		for( int j = 0 ; j < del_strcd.length; j++  ){
			int i = 0 ;
			sql.put(svc.getQuery("DEL_DETAIL"));
			sql.setString(++i, del_strcd[j]);
			sql.setString(++i, de_slip_no[j]);
			sql.setString(++i, de_ord_seqno[j]);
			ret += executeUpdate(sql);
			sql.close();
		}
		
		if( ret > 0 ){				
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append(ret);
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}else {
			rollback();
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append("�������� ���ռ� ������ ���Ͽ� \n������ �Է��� ���� ���߽��ϴ�.");
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}
		
		
	}catch(Exception e){
		rollback();
		throw e;
	} finally {
		end();
	}
	return sb;
}  

public StringBuffer getSkuInfo(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;		
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String d_pumbuncd = String2.nvl(form.getParam("d_pumbuncd"));											//���ڵ�
		String strPummokcd = String2.nvl(form.getParam("strPummokcd"));									//���»��ڵ�
		
		
		connect("pot");
		
		sql.put(svc.getQuery("SEL_SKU_SALE_PRC")); 
		sql.setString(++i, d_pumbuncd);
		sql.setString(++i, strPummokcd);
		
		
		sb = executeQueryByAjax(sql);
		
	}catch(Exception e){
		throw e;
	}
	return sb;
}


public StringBuffer save(ActionForm form, String userid) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int ret 	= 0;
	int res 	= 0;
	int i   	= 0;
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String m_rowStatus = String2.nvl(form.getParam("m_rowStatus"));
		
		if( "3".equals(m_rowStatus) ){		//������ �ű�
			
			ret = masterInsert(form, userid);
		} else {							//������ ����
			
			res = masterModify(form, userid);
		}
		
		
		
		if( ret > 0 || res > 0 ){				
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append((ret+res));
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}else {
			rollback();
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append("�������� ���ռ� ������ ���Ͽ� \n������ �Է��� ���� ���߽��ϴ�.");
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}
		
		
		
	}catch(Exception e){
		rollback();
		throw e;
	} finally {
		end();
	}
	return sb;
} 

public int masterModify(ActionForm form, String userid) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	int res = 0;
	int mstCnt = 0;
	String strSlipNo  = "";		// ��ǥ��ȣ
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String sv_strcd 		= String2.nvl(form.getParam("sv_strcd"));
		String sv_slip_no 		= String2.nvl(form.getParam("sv_slip_no"));
		String sv_slip_flag 	= String2.nvl(form.getParam("sv_slip_flag"));
		String sv_sh_gbn 		= String2.nvl(form.getParam("sv_sh_gbn"));
		String sv_pb_cd 		= String2.nvl(form.getParam("sv_pb_cd"));
		String sv_baljujc 		= String2.nvl(form.getParam("sv_baljujc"));
		String sv_bjdate 		= String2.nvl(form.getParam("sv_bjdate")).trim().replaceAll("/", "");
		String sv_bjhjdate 		= String2.nvl(form.getParam("sv_bjhjdate"));
		String sv_hrs_cd 		= String2.nvl(form.getParam("sv_hrs_cd"));
		String gs_gbn 			= String2.nvl(form.getParam("gs_gbn"));
		String sv_npyjdate 		= String2.nvl(form.getParam("sv_npyjdate")).trim().replaceAll("/", "");
		String buyercd 			= String2.nvl(form.getParam("buyercd"));
		String majindate 		= String2.nvl(form.getParam("majindate")).trim().replaceAll("/", "");
		String sv_hs_gbn 		= String2.nvl(form.getParam("sv_hs_gbn"));
		String sv_hs_rate 		= String2.nvl(form.getParam("sv_hs_rate"));
		String sv_gpwjDate 		= String2.nvl(form.getParam("sv_gpwjDate"));
		String sv_spg 			= String2.nvl(form.getParam("sv_spg")).replaceAll(",","");
		String sv_wgg 			= String2.nvl(form.getParam("sv_wgg")).replaceAll(",","");
		String sv_mgg 			= String2.nvl(form.getParam("sv_mgg")).replaceAll(",","");
		String sv_etc 			= String2.nvl(form.getParam("sv_etc")).replaceAll(",","");
		String sv_gap_tot_amt 	= String2.nvl(form.getParam("sv_gap_tot_amt")).replaceAll(",", "");	//���;���
		String sv_new_gap_rate 	= String2.nvl(form.getParam("sv_new_gap_rate"));					//������
		String sv_vat_tamt 		= String2.nvl(form.getParam("sv_vat_tamt"));						//�ΰ���
		String sv_dtl_cnt 		= String2.nvl(form.getParam("sv_dtl_cnt"));							//�����Ǽ�
		String sv_biz_type 		= String2.nvl(form.getParam("sv_biz_type"));						//biz_type
		String norm_mg_rate 	= String2.nvl(form.getParam("norm_mg_rate"));						//������
		String d_ord_qty 	= String2.nvl(form.getParam("by_d_sv_ord_qty"));				
		
		connect("pot");
		begin();
		 
		i = 1; 
			sql.put(svc.getQuery("UPD_MASTER"));		

			sql.setString(i++, sv_slip_flag);
			sql.setString(i++, sv_sh_gbn);
			sql.setString(i++, sv_pb_cd);
			sql.setString(i++, sv_bjdate);
			sql.setString(i++, sv_npyjdate);
			sql.setString(i++, majindate);
			sql.setString(i++, sv_hs_gbn);
			sql.setString(i++, sv_hs_rate);
			sql.setString(i++, sv_etc);
			sql.setString(i++, sv_spg);
			sql.setString(i++, sv_wgg);
			sql.setString(i++, sv_mgg);
			sql.setString(i++, sv_gap_tot_amt);			//mi1.getString("GAP_TOT_AMT") ���� ���;���
			sql.setString(i++, sv_new_gap_rate);	    //mi1.getString("NEW_GAP_RATE") ����  ��������
			sql.setString(i++, sv_vat_tamt);	    	//mi1.getString("vat amt") ���� �ΰ���   
			sql.setString(i++,  sv_dtl_cnt); 
			sql.setString(i++, sv_strcd);
			sql.setString(i++, sv_slip_no);
			 
			 ret = executeUpdate(sql);
			 
			sql.close();
		    i = 1;				
			sql.put(svc.getQuery("INS_MASTER_LOG"));
			
			sql.setString(i++, sv_strcd);  
			sql.setString(i++, sv_slip_no);;
			sql.setString(i++, sv_slip_flag);
			sql.setString(i++, "00");    
			sql.setString(i++, sv_strcd);  
			sql.setString(i++, sv_slip_no);
			sql.setString(i++, sv_slip_flag);
			sql.setString(i++, "00");
			mstCnt += executeUpdate(sql);	
			    
			    if( ret > 0 ){
	  
			    	String d_sv_strcd [] 			= form.getParam("d_sv_strcd").split("/");
			        String d_sv_rowStatus [] 		= form.getParam("d_sv_rowStatus").split("/");
			        String d_sv_slip_no [] 			= form.getParam("d_sv_slip_no").split("/");
			        String d_sv_ord_seqno [] 		= form.getParam("d_sv_ord_seqno").split("/");
			        String d_sv_no [] 				= form.getParam("d_sv_no").split("/");
			        String d_sv_pummok_cd [] 		= form.getParam("d_sv_pummok_cd").split("/");
			        String d_sv_ord_unit_cd [] 		= form.getParam("d_sv_ord_unit_cd").split("/");
			        String d_sv_ord_qty [] 			= form.getParam("d_sv_ord_qty").split("/");
			        String d_sv_mg_rate [] 			= form.getParam("d_sv_mg_rate").split("/");
			        String d_sv_new_cost_prc [] 	= form.getParam("d_sv_new_cost_prc").split("/");
			        String d_sv_new_cost_amt [] 	= form.getParam("d_sv_new_cost_amt").split("/");
			        String d_sv_new_sale_prc [] 	= form.getParam("d_sv_new_sale_prc").split("/");
			        String d_sv_new_sale_amt [] 	= form.getParam("d_sv_new_sale_amt").split("/");
			        String d_sv_tag_flag [] 		= form.getParam("d_sv_tag_flag").split("/");
			        String d_sv_tag_prt_own_flag [] = form.getParam("d_sv_tag_prt_own_flag").split("/");
			        String d_sv_new_gat_amt [] 		= form.getParam("d_sv_new_gat_amt").split("/");
			        String d_sv_vat_amt []			= form.getParam("d_sv_vat_amt").split("/");

					System.out.println("!234234234234234234234234234!$"+sv_slip_no);
			        res = DetailDelete(form, sv_strcd, sv_slip_no); 

				    if( d_sv_strcd.length > 0 ){
					    for(int j = 0; j < d_sv_strcd.length; j++){
					    	if(!d_sv_new_sale_amt[j].equals("0")) {
							 res += de_insert(form , userid, sv_slip_no, sv_strcd, d_sv_pummok_cd[j], d_sv_ord_unit_cd[j], d_sv_ord_qty[j], d_sv_mg_rate[j],  d_sv_new_cost_prc[j], 
									 d_sv_new_cost_amt[j], d_sv_new_sale_prc[j], d_sv_new_sale_amt[j],d_sv_tag_flag[j], sv_pb_cd, sv_hrs_cd, sv_slip_flag,d_sv_tag_prt_own_flag[j], d_sv_new_gat_amt[j], d_sv_vat_amt[j]);
					    	}
					    }
				    } 
				    UpdateMaster(form, sv_strcd, sv_slip_no);
				 }
 
			System.out.println("!123123!$"+ret);
	}catch(Exception e){
		rollback();
		System.out.println("~~~~~~~~~~~~~~~"+e);
		throw e;
	} finally {
		end();
	}
	 
	return ret;
}

public int UpdateMaster(ActionForm form, String sv_strcd, String sv_slip_no) throws Exception {
	SqlWrapper sql = null;
	Service svc = null;
	int res = 0; 
	
	try{   
		sql = new SqlWrapper();
		svc = (Service) form.getService();
 
		sql.close();
		System.out.println("�ƾƾƾƾƾƾƾƾƾƾ�");
		sql.put(svc.getQuery("UPD_MASTER_LAST"));		

		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ : "+sv_strcd);
		sql.setString(1, sv_strcd);
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! : "+sv_slip_no);
		sql.setString(2, sv_slip_no); 
		res = executeUpdate(sql);
		sql.close();
	}
	catch(Exception e){ 
		System.out.println("����" + e);
		throw e;
	}
	return res;
}

public int DetailDelete(ActionForm form, String strcd, String slipNo ) throws Exception {
	
	
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	String ord_seqNo = "";
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
 
		sql.close();
		sql.put(svc.getQuery("DEL_DETAIL_ALL")); 
		
		sql.setString(1, strcd);
		sql.setString(2, slipNo);
		ret = executeUpdate(sql);
		sql.close();
		 
	}catch(Exception e){ 
		throw e; 
	}
	return ret;
}

/**
 * <p> ��ǥ��ȣ ��ȸ</p>
 * 
 */
public String slipno(ActionForm form) throws Exception{
	String returnJson = null;
	List list = null;
	SqlWrapper sql = null; 
	Service svc = null;
	int i = 0;
	Util util = new Util();
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		String sv_strcd 		= String2.nvl(form.getParam("sv_strcd")); 
		String sv_bjdate 		= String2.nvl(form.getParam("sv_bjdate")).trim().replaceAll("/", ""); 
		  
		connect("pot");
		
		// ��ǥ��ȣ�� �����Ѵ�.(���������)
		sql.put(svc.getQuery("SEL_SLIP_NO"));	
		sql.setString(1, sv_strcd);
		sql.setString(2, sv_bjdate);
		  
		list = executeQueryByList(sql);
		
		String cols = "SLIP_NO";
 
		returnJson = util.listToJsonOBJ(list, cols);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+returnJson);
		
	}catch(Exception e){
		throw e;
	}
	
	return returnJson;
} 

public int masterInsert(ActionForm form, String userid) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	int mstCnt = 0;
	String strSlipNo  = "";		// ��ǥ��ȣ
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String sv_strcd 		= String2.nvl(form.getParam("sv_strcd"));
		String sv_slip_no 		= String2.nvl(form.getParam("sv_slip_no")); 
		String sv_slip_flag 	= String2.nvl(form.getParam("sv_slip_flag"));
		String sv_sh_gbn		= String2.nvl(form.getParam("sv_sh_gbn"));
		String sv_pb_cd 		= String2.nvl(form.getParam("sv_pb_cd"));
		String sv_baljujc 		= String2.nvl(form.getParam("sv_baljujc"));
		String sv_bjdate 		= String2.nvl(form.getParam("sv_bjdate")).trim().replaceAll("/", "");
		String sv_bjhjdate 		= String2.nvl(form.getParam("sv_bjhjdate"));
		String sv_hrs_cd 		= String2.nvl(form.getParam("sv_hrs_cd"));
		String gs_gbn 			= String2.nvl(form.getParam("gs_gbn"));
		String sv_npyjdate 		= String2.nvl(form.getParam("sv_npyjdate")).trim().replaceAll("/", "");
		String buyercd 			= String2.nvl(form.getParam("buyercd"));
		String majindate 		= String2.nvl(form.getParam("majindate")).trim().replaceAll("/", "");
		String sv_hs_gbn 		= String2.nvl(form.getParam("sv_hs_gbn"));
		String sv_hs_rate 		= String2.nvl(form.getParam("sv_hs_rate"));
		String sv_gpwjDate		= String2.nvl(form.getParam("sv_gpwjDate"));
		String sv_spg 			= String2.nvl(form.getParam("sv_spg")).replaceAll(",","");
		String sv_wgg 			= String2.nvl(form.getParam("sv_wgg")).replaceAll(",","");
		String sv_mgg 			= String2.nvl(form.getParam("sv_mgg")).replaceAll(",","");
		String sv_etc 			= String2.nvl(form.getParam("sv_etc")).replaceAll(",","");
		String sv_gap_tot_amt 	= String2.nvl(form.getParam("sv_gap_tot_amt")).replaceAll(",", "");	//���;���
		String sv_new_gap_rate 	= String2.nvl(form.getParam("sv_new_gap_rate"));					//������
		String sv_vat_tamt 		= String2.nvl(form.getParam("sv_vat_tamt"));						//�ΰ���
		String sv_dtl_cnt 		= String2.nvl(form.getParam("sv_dtl_cnt"));							//�����Ǽ�
		String sv_biz_type 		= String2.nvl(form.getParam("sv_biz_type"));						//biz_type
		String norm_mg_rate 	= String2.nvl(form.getParam("norm_mg_rate"));						//������
		String d_ord_qty 	= String2.nvl(form.getParam("by_d_sv_ord_qty"));						  
		
		connect("pot");
		begin(); 
		
	/*	// ��ǥ��ȣ�� �����Ѵ�.(���������)
		sql.put(svc.getQuery("SEL_SLIP_NO"));	
		sql.setString(1, sv_strcd);
		sql.setString(2, sv_bjdate);
		
		Map mapSlipNo = (Map)executeQueryByMap(sql);
		strSlipNo = mapSlipNo.get("SLIP_NO").toString();*/
		 
		sql.close();
		
		String strDetailCount	= String2.nvl(form.getParam("sv_dtl_cnt"));
		
		
		
		i = 1; 
		// 3. ���������̺��� ����
		
			sql.put(svc.getQuery("INS_MASTER"));
			
			 sql.setString(i++, sv_slip_no); 
			 sql.setString(i++, sv_strcd);  
			 sql.setString(i++, sv_pb_cd); 
			 sql.setString(i++, sv_hrs_cd);   
			 sql.setString(i++, sv_slip_flag);
			 sql.setString(i++, "1");  							/* ������ü���� : 0(��ȭ������) */ 
			 sql.setString(i++, "0");    						/* ���ֱ���           : 0(�Ϲ�) */  
			 sql.setString(i++, "0"); 							/* �ڵ���ǥ���� : 0(�Ϲ���ǥ) */   
			 sql.setString(i++, "0"); 							/* �������ı��� : 0(������ǥ) */ 
			 sql.setString(i++, sv_bjdate);						/* ������ */    
			 sql.setString(i++, sv_npyjdate);					/* ��ǰ������ */
			 sql.setString(i++, majindate);						/* ���������� */
			 sql.setString(i++, sv_hs_gbn);						/* ��籸�� */
			 sql.setString(i++, sv_hs_rate);					/* ����� */
			 sql.setString(i++, "        ");					/* SMȮ������ */
			 sql.setString(i++, "");							/* SM ID */  
			 sql.setString(i++, "");							/* ���̾�ID */
			 sql.setString(i++, "        ");					/* ���̾�Ȯ������(����Ȯ������) */ 
			 sql.setString(i++, buyercd);          
			 sql.setString(i++, "00");   
			 sql.setString(i++, sv_dtl_cnt);     
			 sql.setString(i++, sv_spg);						//mi1.getString("ORD_TOT_QTY") ������ 
			 sql.setString(i++, sv_wgg); 						//mi1.getString("NEW_COST_TAMT") ������
			 sql.setString(i++, sv_mgg);  						//mi1.getString("NEW_SALE_TAMT")  �Ű��� 
			 sql.setString(i++, sv_gap_tot_amt); 				//GAP_TOT_AMT  �����;�
			 sql.setString(i++, sv_new_gap_rate);  				//NEW_GAP_RATE ��������
			 sql.setString(i++, sv_vat_tamt);  					//VAT_TAMT �ΰ���
			 sql.setString(i++, sv_etc);        
			 sql.setString(i++, sv_biz_type);      
			 sql.setString(i++, gs_gbn);     
			 sql.setString(i++, "N");   
			 sql.setString(i++, userid); 
			 sql.setString(i++, userid);
			 sql.setString(i++, userid);  
			 
			 ret = executeUpdate(sql);
			 sql.close();
			
			i = 1; 
			sql.put(svc.getQuery("INS_MASTER_LOG"));
			sql.setString(i++, sv_strcd);  
			sql.setString(i++, sv_slip_no);
			sql.setString(i++, sv_slip_flag);
			sql.setString(i++, "00");    
			sql.setString(i++, sv_strcd);  
			sql.setString(i++, sv_slip_no);
			sql.setString(i++, sv_slip_flag);
			sql.setString(i++, "00");
			
			mstCnt = executeUpdate(sql);
			sql.close();
			
			if( ret > 0 ){	
				String d_sv_strcd [] = form.getParam("d_sv_strcd").split("/");
				
				if( d_sv_strcd.length > 0 ){
					 String d_sv_rowStatus [] 			= form.getParam("d_sv_rowStatus").split("/");
				     String d_sv_slip_no []	 			= form.getParam("d_sv_slip_no").split("/");
				     String d_sv_ord_seqno [] 			= form.getParam("d_sv_ord_seqno").split("/");
				     String d_sv_no [] 					= form.getParam("d_sv_no").split("/");
				     String d_sv_pummok_cd [] 			= form.getParam("d_sv_pummok_cd").split("/");
				     String d_sv_ord_unit_cd [] 		= form.getParam("d_sv_ord_unit_cd").split("/");
				     String d_sv_ord_qty [] 			= form.getParam("d_sv_ord_qty").split("/");
				     String d_sv_mg_rate [] 			= form.getParam("d_sv_mg_rate").split("/");
				     String d_sv_new_cost_prc [] 		= form.getParam("d_sv_new_cost_prc").split("/");
				     String d_sv_new_cost_amt [] 		= form.getParam("d_sv_new_cost_amt").split("/");
				     String d_sv_new_sale_prc [] 		= form.getParam("d_sv_new_sale_prc").split("/");
				     String d_sv_new_sale_amt [] 		= form.getParam("d_sv_new_sale_amt").split("/");
				     String d_sv_tag_flag [] 			= form.getParam("d_sv_tag_flag").split("/");
				     String d_sv_tag_prt_own_flag []	= form.getParam("d_sv_tag_prt_own_flag").split("/");
				     String d_sv_new_gat_amt [] 		=  form.getParam("d_sv_new_gat_amt").split("/");
				     String d_sv_vat_amt [] 			=  form.getParam("d_sv_vat_amt").split("/");
				     
				     System.out.println("####################### d_sv_vat_amt : " +form.getParam("d_sv_vat_amt"));
				//     System.out.println("####################### d_sv_vat_amt : " +form.getParam("d_sv_vat_amt"));
				     
				     for(int j = 0; j < d_sv_strcd.length; j++){
				    	 if(!d_sv_rowStatus[j].equals("3")  ){		//������ �ű�
				    		 System.out.println(j +" ��°  �ű� ����  rowStatus : " + d_sv_rowStatus[j]); 
						    	if(!d_sv_new_sale_amt[j].equals("0")) {
								 ret += de_insert(form , userid, sv_slip_no, sv_strcd, d_sv_pummok_cd[j], d_sv_ord_unit_cd[j], d_sv_ord_qty[j], d_sv_mg_rate[j],  d_sv_new_cost_prc[j], 
										 d_sv_new_cost_amt[j], d_sv_new_sale_prc[j], d_sv_new_sale_amt[j],d_sv_tag_flag[j], sv_pb_cd, sv_hrs_cd, sv_slip_flag,d_sv_tag_prt_own_flag[j], d_sv_new_gat_amt[j], d_sv_vat_amt[j]);
						    	}
				    		 }

				     }
				    
				     // �ű�/���� ����� Detail ���� �� Detail �����ͷ� MASTER UPDATE
				     UpdateMaster(form, sv_strcd, sv_slip_no); 
				}
				
			}
		  
	}catch(Exception e){
		rollback();
		throw e;
	} finally {
		end();
	}
	return ret;
}
                                                                               
public int de_modify(ActionForm form, String userid, String strSlipNo, String strcd, String slip_no, String ord_seqno, String pummokcd, String ord_unit_cd, String ord_qty, String mg_rate, String new_cost_prc,
		String new_cost_amt, String new_sale_prc, String new_sale_amt, String sv_tag_flag, String pumbuncd, String vencd, String slip_flag, String tag_prt_own_flag, String new_gap_amt) throws Exception {
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
	    
	    
	    connect("pot");
		begin();

		i = 1; 
		sql.put(svc.getQuery("UPD_DETAIL")); 
		sql.setString(i++, pummokcd);
		sql.setString(i++, ord_unit_cd.replaceAll(",", "")); 
		sql.setString(i++, mg_rate.replaceAll("%", ""));		//������
		sql.setString(i++, ord_qty.replaceAll(",", ""));
		sql.setString(i++, new_cost_prc.replaceAll(",", ""));
		sql.setString(i++, new_cost_amt.replaceAll(",", ""));
		sql.setString(i++, new_sale_prc.replaceAll(",", ""));
		sql.setString(i++, new_sale_amt.replaceAll(",", ""));
		sql.setString(i++, "0");					//mi2.getString("NEW_GAP_AMT") �����;�
		sql.setString(i++, mg_rate.replaceAll("%", ""));      //��������
		sql.setString(i++, pumbuncd);
		sql.setString(i++, vencd);
		sql.setString(i++, slip_flag);
		sql.setString(i++, sv_tag_flag);
		sql.setString(i++, tag_prt_own_flag);  			//�ù�����ü		�����Ұ�		
		sql.setString(i++, userid);							//������						
		sql.setString(i++, strcd);
		sql.setString(i++, slip_no);		
		sql.setString(i++, ord_seqno);
		
		ret = executeUpdate(sql);

	}catch(Exception e){
		rollback();
		throw e;
	} finally {
		end();
	}
	
	return ret;
	
	
}

public int de_insert(ActionForm form, String userid, String sv_slip_no, String strcd, String pummokcd, String ord_unit_cd, String ord_qty, String mg_rate, String new_cost_prc,
		String new_cost_amt, String new_sale_prc, String new_sale_amt, String tag_flag, String pumbuncd, String vencd, String slip_flag, String tag_prt_own_flag, String new_gap_amt, String vat_amt) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	String strSlip = "";
	String ord_seqNo = "";
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();

		sql.close();
								
		// 1. ��ǥ�󼼹�ȣ ����
		sql.put(svc.getQuery("SEL_ORD_SEQ_NO"));
		sql.setString(1, strcd);								//���ڵ� ���޾ƿ´�
		sql.setString(2, sv_slip_no);
		Map mapSeqNo = (Map)executeQueryByMap(sql);
		ord_seqNo = mapSeqNo.get("ORD_SEQ_NO").toString();
		sql.close();
		
		i = 1; 
		sql.put(svc.getQuery("INS_DETAIL"));
		
		sql.setString(i++, strcd);							//���ڵ� ���޾ƿ´�
		sql.setString(i++, sv_slip_no);						
		sql.setString(i++, ord_seqNo);			
		sql.setString(i++, pummokcd);	  
		sql.setString(i++, "        ");                    /* ��ǰ�ڵ� */   											
		sql.setString(i++, ord_unit_cd.replaceAll(",", ""));
		sql.setString(i++, mg_rate);
		sql.setString(i++, ord_qty.replaceAll(",", ""));	
		sql.setString(i++, mg_rate);							//���������� �������� ����
		sql.setString(i++, new_gap_amt);									//mi2.getString("NEW_GAP_AMT") �����̾�
		sql.setString(i++, new_cost_prc.replaceAll(",", ""));
		sql.setString(i++, new_cost_amt.replaceAll(",", ""));
		sql.setString(i++, new_sale_prc.replaceAll(",", ""));
		sql.setString(i++, new_sale_amt.replaceAll(",", ""));
		sql.setString(i++, vat_amt);  		                    		/* �ΰ���  */
		sql.setString(i++, pumbuncd);							//ǰ���ڵ�		
		sql.setString(i++, vencd);								//���»��ڵ�
		sql.setString(i++, slip_flag);							
		sql.setString(i++, tag_flag);							//�� ����
		sql.setString(i++, tag_prt_own_flag);					//�� ���� ��ü �����Ұ�
		sql.setString(i++, userid);
		sql.setString(i++, userid); 	
		
		ret = executeUpdate(sql);
		

		System.out.println("!^!^!^!^!^!^!^!^"+sv_slip_no);
	//	strSlip = int(strSlipNo);
	}catch(Exception e){ 
		throw e; 
	}
	
	return ret;
}


public StringBuffer delete(ActionForm form) throws Exception{
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;	
	int ret = 0;
	String ord_seqNo = "";
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
	    String strcd = String2.nvl(form.getParam("strcd"));
	    String slip_no = String2.nvl(form.getParam("slip_no"));
	    
	    
	    
	    connect("pot");
		begin();
		
		sql.close();
		sql.put(svc.getQuery("DEL_DETAIL_ALL")); 
		
		sql.setString(1, strcd);
		sql.setString(2, slip_no);
		ret = executeUpdate(sql);
		
		sql.close();
		sql.put(svc.getQuery("DEL_DETAIL_LOG")); 
		
		sql.setString(1, strcd);
		sql.setString(2, slip_no);
		ret = executeUpdate(sql);
		
		sql.close();
		sql.put(svc.getQuery("DEL_MASTER")); 
		
		sql.setString(1, strcd);
		sql.setString(2, slip_no);
		ret = executeUpdate(sql);
		
		if( ret > 0 ){				
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append(ret);
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}else {
			rollback();
			sb.append("<?xml version='1.0' encoding='utf-8'?>");
			sb.append("<t>");
			sb.append("<r id='1'>");
			sb.append("<c id='RET'>").append("�������� ���ռ� ������ ���Ͽ� \n������ �Է��� ���� ���߽��ϴ�.");
			sb.append("</c>");
			sb.append("</r>");
			sb.append("</t>");
		}
		
	}catch(Exception e){
		rollback();
		throw e;
	} finally {
		end();
	}
	
	return sb;
}


public StringBuffer getVenRoundFlag(ActionForm form) throws Exception {
	
	StringBuffer sb = null;
	SqlWrapper sql = null;
	Service svc = null;
	int i = 0;		
	
	try{
		sql = new SqlWrapper();
		svc = (Service) form.getService();
		sb = new StringBuffer();
		
		String strStrCd = String2.nvl(form.getParam("strcd"));											//���ڵ�
		String strToday = String2.nvl(form.getParam("strToday"));									//���»��ڵ�
		String ven_cd = String2.nvl(form.getParam("ven_cd"));									//���»��ڵ�
		
		
		connect("pot");
		
		sql.put(svc.getQuery("SEL_ROUNDFLAG"));
		sql.setString(++i, strStrCd);
		sql.setString(++i, ven_cd);
		
		
		sb = executeQueryByAjax(sql);
		
		
	}catch(Exception e){
		throw e;
	}
	return sb;
}


	
}
